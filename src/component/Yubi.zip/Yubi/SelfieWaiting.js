"use client";

export default function SelfieWaiting() {
  return (
    <div style={{ textAlign: "center", marginTop: "20%" }}>
      <h2>Verifying your KYC...</h2>
      <p>
        Please do not close this window.
        <br />
        Your application will be disbursed automatically once verification is
        complete.
      </p>
    </div>
  );
}
