"use client";
import React, { useEffect, useRef } from "react";
import "./KfsCompleted.css";
import { Roboto } from "next/font/google";
// import axios from "axios";
// import CallbackListener from "../CallbackListener";

const roboto = Roboto({
  weight: ["400", "700"],
  subsets: ["latin"],
});

const LoadingPage = () => {
  const clientLoanId = localStorage.getItem("clientLoanId");
  const hasCalledApi = useRef(false);

  useEffect(() => {
    if (!clientLoanId) {
      console.error("❌ Client Loan ID not found in localStorage");
      return;
    }

    if (hasCalledApi.current) {
      console.log("⚠️ Skipping duplicate API call");
      return;
    }
    hasCalledApi.current = true;

    const docType = localStorage.getItem("documentTypeStatus");
    if (docType === "kfs_doc") {
      const callLoanAgreementAPI = async () => {
        try {
          const res = await axios.post(
            `http://localhost:8080/generateLoanAgreementDocument`,
            { clientLoanId }
          );
          console.log("✅ Loan Agreement API called:", res.data);
        } catch (err) {
          console.error("❌ Loan Agreement API error:", err);
        }
      };
      callLoanAgreementAPI();
    }
  }, [clientLoanId]);
  return (
    <div className={`${roboto.className} waiting-table`}>
      <div className="loading-circle">
        <svg className="hourglass-icon" viewBox="0 0 24 24" fill="none">
          <path
            d="M6 2v6h.01L6 8.01 10 12l-4 4 .01.01H6V22h12v-5.99h-.01L18 16l-4-4 4-3.99-.01-.01H18V2H6z"
            fill="#6039D2"
            stroke="#6039D2"
            strokeWidth="2.5"
          />
        </svg>
      </div>

      <div className="status-box">
        <div className="status-row">
          <div className="status-icon">✅</div>
          <div className="status-text">KFS Completed</div>
        </div>
        <div className="status-row">
          <div className="status-icon"></div>
          <div className="status-text">Agreement...</div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="Long-button">
        <button type="submit" className="form-submit">
          Next
        </button>
      </div>

      {/* <CallbackListener
        onEsignReady={async () => {
          console.log("✅ Loan Agreement doc generated webhook received!");

          try {
            const res = await axios.post(`http://localhost:8080/requestEsign`, {
              clientLoanId,
              // email: "user@example.com",
              // phone: "9999999999",
              // firstName: "John",
              // lastName: "Doe",
            });
            console.log("✅ eSign API Response:", res.data);

            const redirectUrl = res.data?.obj;
            if (redirectUrl) {
              window.location.href = redirectUrl;
            }
          } catch (err) {
            console.error("❌ eSign API error:", err);
          }
        }}
      /> */}
    </div>
  );
};

export default LoadingPage;
